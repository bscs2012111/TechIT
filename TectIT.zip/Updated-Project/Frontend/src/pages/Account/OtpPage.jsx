import React from 'react'
import OtpForm from '../../layout/Account/OtpForm'

const OtpPage = () => {

  return (
    
    <div>
      <OtpForm/>
    </div>
  )
}

export default OtpPage
