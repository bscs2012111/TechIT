import React from 'react'
import SendOtpForm from '../../layout/Account/SendOtp'
const SendOtp = () => {
  return (
    <div>
      <SendOtpForm/>
    </div>
  )
}

export default SendOtp
