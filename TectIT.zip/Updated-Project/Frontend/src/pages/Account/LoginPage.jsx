import React from 'react'
import LoginForm from '../../layout/Account/LoginForm'

const LoginPage = () => {
  return (
    <>
      <LoginForm/>
    </>
  )
}

export default LoginPage
