import React from 'react'
import ChangePassword from '../../layout/Account/ChangePassword'

const ChangePasswordPage = () => {
  return (
    <div>
      <ChangePassword/>
    </div>
  )
}

export default ChangePasswordPage
