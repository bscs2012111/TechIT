import React from 'react'
import RegisterForm from '../../layout/Account/RegisterForm'
const RegisterPage = () => {
  return (
    <>
      <RegisterForm/>
    </>
  )
}

export default RegisterPage
