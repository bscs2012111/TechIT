import React from 'react'
import Main from '../../layout/User/SingleProduct/Main'

const SingleProductPage = () => {
  return (
    <div>
      <Main/>
    </div>
  )
}

export default SingleProductPage
