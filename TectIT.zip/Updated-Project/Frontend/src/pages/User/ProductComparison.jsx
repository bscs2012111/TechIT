import React from 'react'
import Main from '../../layout/User/Comparison/Main'

const ProductComparison = () => {
  return (
    <div>
      <Main/>
    </div>
  )
}

export default ProductComparison
