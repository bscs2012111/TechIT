import React from 'react'
import Main from '../../layout/User/Home/Main'

const HomePage = () => {
    
  return (
    <div>
      <Main/>
    </div>
  )
}

export default HomePage
