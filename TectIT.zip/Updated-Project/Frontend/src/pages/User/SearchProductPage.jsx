import React from 'react'
import Main from '../../layout/User/SearchProduct/Main'

const SearchProductPage = () => {
  return (
    <div>
      <Main/>
    </div>
  )
}

export default SearchProductPage
