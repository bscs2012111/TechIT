import React from 'react'
import Navbar from '../Navbar'
import Comaprison from './Comaprison'


const Main = () => {
  return (
    <div>
      <Navbar/>
      <Comaprison/>
    </div>
  )
}

export default Main