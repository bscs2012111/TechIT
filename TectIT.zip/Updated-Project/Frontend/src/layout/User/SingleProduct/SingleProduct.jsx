import React, { useEffect, useState } from 'react'
import { FaStar } from "react-icons/fa";
import { FiPlus, FiMinus } from "react-icons/fi";
import { AiOutlineHeart } from "react-icons/ai";
import axios from 'axios'
import { baseUrl } from '../../../constants/baseUrl'
import { useLocation } from 'react-router-dom';

const SingleProduct = () => {
  const stars = [1, 2, 3, 4, 5]
  const [changeQuantity, setChangeQuantity] = useState(1)
  const [productData, setproductData] = useState([])
  const productId = useLocation().pathname.split('/')[3]

  const [imageIndex, setImageIndex] = useState(0)

  const getSingleProduct = () => {
    axios.get(`${baseUrl}/product/get-product/${productId}`)
      .then((res) => {
        setproductData(res.data?.data)
      })
  }
  useEffect(() => {
    getSingleProduct()
  }, [])


  return (
    <div className='p-3 font-lato bg-[#f4f3f4] overflow-y-auto pb-[8rem] '>

      <h1 className='text-xl font-lato'>{productData?.title}</h1>

      {/* MAIN PRODUCT DETAILS  */}
      <div className='flex justify-center items-start gap-x-8 mt-10 lg:flex-row flex-col'>

        {/* IMAGES  */}

        <div className='flex justify-center w-[100%] lg:w-fit lg:justify-normal items-start gap-x-5 lg:mb-0 mb-10'>
          {/* SMALL IMAGES  */}
          <div>

            {
              productData?.images?.map((item, index) => {
                return (
                  <div onClick={() => setImageIndex(index)} className='bg-[#e1e1e1] cursor-pointer sm:w-[5rem] sm:h-[4rem] w-[3rem] h-[3rem]  flex justify-center items-center mb-4'>
                    <img src={item?.url} alt="" className='sm:h-[2rem] h-[1rem]' />
                  </div>

                )
              })
            }

          </div>

          {/* LARGE IMAGE  */}
          <div className='bg-[#e1e1e1] flex justify-center items-center h-[18rem] p-2'>
            <img src={productData?.images && productData?.images[imageIndex]?.url} alt="" className='h-[16rem] w-[20rem]' />
          </div>

        </div>

        {/* DETAILS  */}
        <div className='flex flex-col justify-start items-start lg:block w-[100%] lg:w-fit'>
          {/* TITLE  */}
          <h1 className='font-mono text-xl'>{productData?.title}</h1>
          {/* PRICE AND DISCOUNTED PRICED  */}
          <div className='flex gap-x-4 items-start mt-2'>
            {/* <strike className='font-lato text-xl font-medium'>Rs {productData?.price}</strike> */}
            <p className='font-lato text-xl font-medium'>Rs {productData?.price}</p>
          </div>
          {/* STARS AND RATING  */}
          {/* <div className='flex gap-x-4 items-start mt-2'>
            <div className='flex items-start mt-1'>
              {
                stars.map((item) => {
                  return (
                    <FaStar className={`${item <= 4 ? "text-[#ffe44a]" : "text-[#737379]"}`} key={item} />
                  )
                })
              }
            </div>
            <div>
              <p className='text-[#7d7b7d]'>( 1 customer review )</p>
            </div>
          </div> */}
          {/* DESCRIPTION  */}
          <div className='mt-3'>
            <p className=' w-[100%] lg:w-[40rem] text-base text-[#7d7b7d]'>{productData?.description}</p>
          </div>
          {/* BUTTONS  */}
          <div className='flex gap-x-4 items-start mt-3 sm:w-fit w-[100%] justify-center'>
            <div className='flex justify-between items-center w-[10rem] h-[2.5rem] rounded-3xl bg-white p-3'>
              <FiMinus onClick={() => setChangeQuantity(changeQuantity === 1 ? 1 : changeQuantity - 1)} className='cursor-pointer' />
              <p>{changeQuantity}</p>
              <FiPlus onClick={() => setChangeQuantity(changeQuantity + 1)} className='cursor-pointer' />
            </div>
            <div>
              <button className='w-[10rem] h-[2.5rem] rounded-3xl bg-[#6616db] text-white font-mont font-medium'>Add To Cart</button>
            </div>
          </div>
          {/* ADD TO WISHLIST  */}
          <div className='flex gap-x-3 items-center mt-4 cursor-pointer text-sm'>
            <AiOutlineHeart />
            <p className='font-mont font-medium'>Add To Wishlist</p>
          </div>
          {/* TAGS  */}
          {/* <div className='flex gap-x-3 items-center mt-4 cursor-pointer text-sm'>
            <div>
              <p>Tags: </p>
            </div>
            <div className='flex gap-x-3'>
              <p>Fashion ,</p>
              <p>Jacket ,</p>
              <p>Man ,</p>
              <p>Summer</p>
            </div>
          </div> */}
          {/* CHECKOUT IMAGE  */}
          {/* <div className='mt-4'>
            <img src={CheckOutImage} alt="" className=' w-[100%] sm:w-[20rem]' />
          </div> */}

        </div>


      </div>


    </div>
  )
}

export default SingleProduct
