import React, { useEffect, useState } from 'react'
import Navbar from '../Navbar'
import Hero from './Hero'
import Services from './Services'
import CategoriesCard from './CategoriesCard'
import ProductListing from '../../../components/ProductListing'
import axios from 'axios'
import { baseUrl } from '../../../constants/baseUrl'

const Main = () => {

  const [productData,setProductData] = useState([])
  const getAllProducts = ()=>{
    axios.get(`${baseUrl}/product/get-all-active-products`)
    .then((res)=>{setProductData(res.data)})
    .catch((e)=>console.log(e))
  }

  useEffect(()=>{
    getAllProducts()
  },[])
  return (
    <div>
      <Navbar productData={productData}/>
      <Hero/>
      <Services/>
      {/* <CategoriesCard/> */}
      <ProductListing productData={productData} title={"Feature Products"} paragraph={""}/>
      <ProductListing productData={productData} title={"Best Selling"} isVertical={true} paragraph={""}/>
      <ProductListing productData={productData} title={"Newest Arrival"} paragraph={""}/>


    </div>
  )
}

export default Main
