import React from 'react';
import BgImg1 from '../../../assets/home/bgImg.jpg';
import BgImg2 from '../../../assets/home/bgImg2.jpg';
import BgImg3 from '../../../assets/home/B-1.jpeg';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/swiper-bundle.css';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const Hero = () => {
  return (
    <div className='bg-cover bg-center pl-3 pr-3 font-lato w-screen h-[30rem] z-0'>
      <Swiper
        spaceBetween={0}
        slidesPerView={1}
        autoplay={{ delay: 2000, disableOnInteraction: false }}
        loop={true}
        pagination={{ clickable: true }}
        navigation={true}
        modules={[Autoplay, Pagination, Navigation]}
        className='z-0'
      >
        <SwiperSlide>
          <div
            className='bg-cover bg-center w-full h-[30rem]'
            style={{ backgroundImage: `url(${BgImg1})` }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className='bg-cover bg-center w-full h-[30rem]'
            style={{ backgroundImage: `url(${BgImg2})` }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className='bg-cover bg-center w-full h-[30rem]'
            style={{ backgroundImage: `url(${BgImg3})` }}
          ></div>
        </SwiperSlide>
      </Swiper>


    </div>
  );
};

export default Hero;

