import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AiFillCompass, AiOutlineHeart } from "react-icons/ai";
import { IoCartOutline } from "react-icons/io5";
import { FaStar } from "react-icons/fa";

const ProductListing = ({ title, paragraph, productData, isVertical }) => {
  const stars = [1, 2, 3, 4, 5];
  const [productIds, setProductIds] = useState([]);
  const nav = useNavigate();

  const saveCompareId = (id) => {
    if (productIds.includes(id)) {
      setProductIds(productIds.filter((productId) => productId !== id));
    } else {
      setProductIds([...productIds, id]);
    }
  };

  useEffect(() => {
    productIds.length === 2 &&
      nav(`/user/product/p1/${productIds[0]}/p2/${productIds[1]}`);
  }, [productIds]);

  console.log(productIds);

  return (
    <div className="pl-3 pr-3 font-lato pb-10">
      {/* TITLE AND DESCRIPTION  */}
      <div className="flex justify-center items-center flex-col">
        <h1 className="text-3xl text-center font-mont font-bold text-[#ff496c] mb-2">
          {title}
        </h1>
        <p className=" w-[100%] sm:w-[60%] text-center text-[#818183]">
          {paragraph}
        </p>
      </div>

      {/* MAIN PRODUCT CARD  */}

      {productData && productData?.data?.length > 0 ? (
        <div
          className={`flex ${
            isVertical ? "lg:justify-center" : "justify-center"
          }  items-center gap-x-5 ${
            isVertical ? "overflow-x-scroll" : "flex-wrap"
          } mt-10`}
        >
          {productData?.data?.map((item, index) => {
            // onClick={()=>nav(`/user/product/${item?._id}`)}
            return (
              <div
                key={item + index}
                className="w-[15rem] min-w-[15rem] h-fit mb-6 "
                onClick={(event) => {
                  event.preventDefault();
                  nav(`/user/product/${item?._id}`);
                }}
              >
                {/* IMAGE  */}
                <div className="w-[100%] cursor-pointer h-[20rem] flex justify-center items-center bg-[#e1e1e1] relative">
                  <img
                    src={item?.images && item?.images[0]?.url}
                    alt=""
                    className="h-[fit] w-fit"
                  />
                  <div
                    onClick={(event) => {
                      event.stopPropagation(); // Prevent parent onClick
                    }}
                    className="absolute bottom-3 right-2 bg-white w-[2rem] h-[2rem] rounded-full flex justify-center items-center cursor-pointer"
                  >
                    <AiOutlineHeart />
                  </div>
                  <div
                    onClick={(event) => {
                      event.stopPropagation(); // Prevent parent onClick
                    }}
                    className="absolute bottom-14 right-2 bg-white w-[2rem] h-[2rem] rounded-full flex justify-center items-center cursor-pointer"
                  >
                    <IoCartOutline />
                  </div>
                  <div
                    onClick={(event) => {
                      event.stopPropagation();
                      saveCompareId(item?._id);
                    }}
                    className={`${
                      productIds.includes(item?._id)
                        ? "bg-blue-300"
                        : "bg-white"
                    } absolute top-4 right-2  w-[2rem] h-[2rem] rounded-full flex justify-center items-center cursor-pointer`}
                  >
                    <AiFillCompass />
                  </div>
                </div>

                {/* TITLE PRICE STARS */}
                <div className="mt-2">
                  <h1 className="text-sm font-lato font-bold">{item?.title}</h1>
                  <div className="flex items-start mt-1">
                    {stars.map((item) => {
                      return (
                        <FaStar
                          className={`${
                            item <= 4 ? "text-[#ffe44a]" : "text-[#737379]"
                          }`}
                          key={item}
                        />
                      );
                    })}
                  </div>
                  <h1 className="text-sm font-mont mt-1">Rs: {item?.price}</h1>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-xl mt-4 text-center font-mont"> NO PRODUCT FOUND </p>
      )}
    </div>
  );
};

export default ProductListing;
