const roles = ["CUSTOMER", "SELLER", "SUPER_ADMIN"];

module.exports = {
  roles,
};
