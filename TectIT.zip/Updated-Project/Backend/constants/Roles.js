const ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  CUSTOMER: "CUSTOMER",
  SELLER: "SELLER",
};

module.exports = {
  ROLES,
};
