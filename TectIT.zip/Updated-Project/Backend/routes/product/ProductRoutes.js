const express = require("express");
const router = express.Router();

const {
  createNewProduct,
  getAllActiveProducts,
  getAllProducts,
  getSingleProduct,
} = require("../../controllers/product/ProductController");

const {
  authenticateUser,
  validateIsCustomer,
  validateIsSeller,
} = require("../../middlewares/Auth");

router.post(
  "/create-new-product",
  authenticateUser,
  validateIsSeller,
  createNewProduct
);

router.get("/get-product/:productId", getSingleProduct);

router.get("/get-all-active-products", getAllActiveProducts);

router.get("/get-all-products", authenticateUser, getAllProducts);

module.exports = router;
