const express = require("express");
const router = express.Router();

const {
  updateApprovalStatusOfSellerAccount,
  getAllSellers,
  getAdminDashboardStatistics,
} = require("../../controllers/admin/AdminController");

const { authenticateUser, validateIsAdmin } = require("../../middlewares/Auth");

router.patch(
  "/change-seller-account-status/:sellerId",
  authenticateUser,
  validateIsAdmin,
  updateApprovalStatusOfSellerAccount
);

router.get(
  "/get-all-sellers",
  authenticateUser,
  validateIsAdmin,
  getAllSellers
);

router.get(
  "/get-dashboard-statistics",
  authenticateUser,
  validateIsAdmin,
  getAdminDashboardStatistics
);

module.exports = router;
